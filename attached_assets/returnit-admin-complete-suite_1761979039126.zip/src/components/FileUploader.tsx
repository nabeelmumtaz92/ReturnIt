// FileUploader.tsx
export default function FileUploader(){return <div>FileUploader Component</div>}
