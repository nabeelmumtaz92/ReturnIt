// PaymentLedger.tsx
export default function PaymentLedger(){return <div>PaymentLedger Component</div>}
