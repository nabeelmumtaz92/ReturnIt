// OrderTable.tsx
export default function OrderTable(){return <div>OrderTable Component</div>}
