// PayoutTable.tsx
export default function PayoutTable(){return <div>PayoutTable Component</div>}
