// StatusBadge.tsx
export default function StatusBadge(){return <div>StatusBadge Component</div>}
