// ManualOrderCreation.tsx
export default function ManualOrderCreation(){return <div>ManualOrderCreation Page</div>}
